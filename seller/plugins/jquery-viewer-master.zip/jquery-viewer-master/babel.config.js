module.exports = {
  presets: [
    [
      '@babel/preset-env',
      {
        modules: false,
      },
    ],
  ],
  env: {
    test: {
      plugins: [
        'istanbul',
      ],
    },
  },
};
